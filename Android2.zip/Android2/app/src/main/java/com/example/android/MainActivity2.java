package com.example.android;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {

    EditText txtIdcliente, txtNombre, txtApellido, txtTelefono, txtEmail;
    Button btnBuscar;
    String idcliente;

    RequestQueue requestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        requestQueue = Volley.newRequestQueue(this);

        Bundle extras = getIntent().getExtras();
        if (extras!= null) {
            idcliente = extras.getString("idcliente");
        }

        initUI();

        btnBuscar.setOnClickListener(this);
        readUser();

    }

    private void initUI(){
        txtIdcliente = findViewById(R.id.txtIdcliente);
        txtNombre = findViewById(R.id.txtNombre);
        txtApellido = findViewById(R.id.txtApellido);
        txtTelefono = findViewById(R.id.txtTelefono);
        txtEmail = findViewById(R.id.txtEmail);

        btnBuscar = findViewById(R.id.btnBuscar);

    }

    private void readUser() {
        String URL = "http://192.168.100.137/android_bd/fetch.php?id=" + idcliente;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                URL,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String nombre, apellido, telefono, email;
                        try {
                            nombre = response.getString("nombre");
                            apellido = response.getString("apellido");
                            telefono = response.getString("telefono");
                            email = response.getString("email");

                            txtNombre.setText(nombre);
                            txtApellido.setText(apellido);
                            txtTelefono.setText(telefono);
                            txtEmail.setText(email);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error de conexion", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        requestQueue.add(jsonObjectRequest);
    }

    @Override
    public void onClick(@NonNull View v){
        int id = v.getId();

        if(id == R.id.btnBuscar){
            Intent intent = new Intent(this, MainActivity2.class);
                    intent.putExtra("idcliente", txtIdcliente.getText().toString().trim());
            startActivity(intent);
            readUser();

        }else if(id == R.id.btnLimpiar){
        }
    }
}